import telebot
from telebot import types

# Bot tokeningiz
TOKEN = "8248683687:AAHyvMik_5tyzXg4VqRn-Ecr7V3vnZMs7zY"

bot = telebot.TeleBot(TOKEN)

# Faqat admin bo'lgan joylarda ishlashi uchun
def is_admin(message):
    try:
        chat_admins = bot.get_chat_administrators(message.chat.id)
        for admin in chat_admins:
            if admin.user.id == message.from_user.id:
                return True
    except:
        pass
    return False

@bot.message_handler(func=lambda message: True)
def delete_replied_or_forwarded(message):
    # Faqat admin bo'lsa
    if not is_admin(message):
        return

    # Reply yoki forward bo'lgan xabarlarni o'chirish
    if message.reply_to_message or message.forward_from or message.forward_from_chat:
        try:
            bot.delete_message(message.chat.id, message.message_id)
        except:
            pass

print("Bot ishga tushdi...")
bot.infinity_polling()
